<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\DB;

use App\Models\Student;


class StudentController extends Controller
{

    public function login(Request $request){
        $credntials = $request->only(['username' , 'password']);
       // $token = Auth::guard('api-admin')->attempt($credntials);
        $token = auth('api-student')->attempt($credntials);

        if(!$token){
            return response()->json([
                'status' => false,
                'msg' =>'This Admin is Not Found',
            ]);
        }
        $student = Auth::guard('api-student')->user();
        $student -> api_token = $token;

        return response() -> json([
            'status' => true ,
            'student' => $student
        ]);
    }

    public function logout(Request $request){
        $token = $request -> header('auth-token');
        if($token){
            try{
                JWTAuth::setToken($token)->invalidate();
            }catch(TokenInvalidException $e){
                return response()->json([
                    'status' => false,
                    'msg' =>'something went wrong',
                ]);
            }

            return response()->json([
                'status' => true,
                'msg' =>'logout successfully',
            ]);

        }
        else{
            return response()->json([
                'status' => false,
                'msg' =>'something went wrong',
            ]);
        }
    }

    public function getStudents(Request $request){
        $students = Student::get();
        return response() -> json([
            'status' => true ,
            'students' => $students,
        ]);
    }

    public function addStudent(Request $request){

        if($request->image == "undefined"){
            $student = Student::create([
                'image' => "user.png" ,
                'year' => $request->year,
                'name' => $request->name,
                'username' => $request->username,
                'password' => password_hash($request->password, PASSWORD_DEFAULT),
            ]);

            return response() -> json([
                'status' => true ,
                'id' => $student->id,
                'msg' => "student added sucessfully"
            ]);
        }

            $fileName = time() . '.' . $request->image->extension();
            $request->image->storeAs('public/images', $fileName);

            $student = Student::create([
                'image' => $fileName ,
                'year' => $request->year,
                'name' => $request->name,
                'username' => $request->username,
                'password' => password_hash($request->password, PASSWORD_DEFAULT),
            ]);

            return response() -> json([
                'status' => true ,
                'id' => $student->id,
                'msg' => "student added sucessfully"
            ]);
    }

    public function getStudentId(Request $request){
        $student = Student::find($request->id);
        return response() -> json([
            'status' => true ,
            'student' => $student,
        ]);
    }

    public function updateStudent(Request $request){
        $student = Student::find($request->id);

        if($request->image == "undefined"){
            $student ->update([
                'year' => $request->year,
                'name' => $request->name,
                'username' => $request->username,
                'password' => password_hash($request->password, PASSWORD_DEFAULT),
            ]);

            return response() -> json([
                'status' => true ,
                'msg' => "student updated sucessfully"
            ]);
        }

            $fileName = time() . '.' . $request->image->extension();
            $request->image->storeAs('public/images', $fileName);

        $student->update([
            'image' => $fileName,
            'year' => $request->year,
            'name' => $request->name,
            'username' => $request->username,
            'password' => password_hash($request->password, PASSWORD_DEFAULT),
        ]);

        return response() -> json([
            'status' => true ,
            'msg' => "order updated sucessfully"
        ]);
    }

    public function deleteStudent(Request $request){
        $student = Student::find($request->id);
        $student->delete();

        return response() -> json([
            'status' => true ,
            'msg' => "student deleted sucessfully"
        ]);
    }
}
