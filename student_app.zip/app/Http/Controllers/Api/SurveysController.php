<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Survey;

class SurveysController extends Controller
{

    public function getSurveys(Request $request){
        $survey = Survey::get();
        return response() -> json([
            'status' => true ,
            'surveys' => $survey,
        ]);
    }

    public function addSurvey(Request $request){
            $survey = Survey::create([
                'subject' => $request->subject ,
                'year' => $request->year,
                'title' => $request->title,
                'degree' => $request->degree,
            ]);
            return response() -> json([
                'status' => true ,
                'id' => $survey->id,
                'msg' => "survey added sucessfully"
            ]);
    }

    public function getSurveyId(Request $request){
        $survey = Survey::find($request->id);
        return response() -> json([
            'status' => true ,
            'survey' => $survey,
        ]);
    }

    public function updateSurvey(Request $request){
        $survey = Survey::find($request->id);
        $survey->update([
            'subject' => $request->subject ,
            'year' => $request->year,
            'title' => $request->title,
            'degree' => $request->degree,
    ]);
        return response() -> json([
            'status' => true ,
            'msg' => "survey updated sucessfully"
        ]);
    }

    public function deleteSurvey(Request $request){
        $survey = Survey::find($request->id);
        $survey->delete();
        return response() -> json([
            'status' => true ,
            'msg' => "survey deleted sucessfully"
        ]);
    }
}
